import streamlit as st
import requests
import matplotlib.pyplot as plt
import pandas as pd
from fpdf import FPDF
from io import BytesIO

# --- Function: Fetch Weather ---
def get_weather(city, api_key):
    url = f"https://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric"
    try:
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            data = response.json()
            return {
                "City": city.title(),
                "Temperature (°C)": data["main"]["temp"],
                "Condition": data["weather"][0]["description"].capitalize(),
                "Humidity (%)": data["main"]["humidity"],
                "Wind Speed (m/s)": data["wind"]["speed"]
            }
        else:
            return {"City": city.title(), "Error": f"Status code {response.status_code}"}
    except:
        return {"City": city.title(), "Error": "Network error"}

# --- Function: Create PDF with Graph ---
def create_pdf(df, graph_path):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", "B", 14)
    pdf.cell(0, 10, "Weather Report", ln=True, align="C")
    pdf.ln(10)

    pdf.set_font("Arial", size=12)
    for i, row in df.iterrows():
        pdf.cell(0, 10, f"{row['City']}: {row['Temperature (°C)']}°C, {row['Condition']}, "
                        f"Humidity: {row['Humidity (%)']}%, Wind: {row['Wind Speed (m/s)']} m/s", ln=True)

    if graph_path:
        pdf.image(graph_path, x=10, w=190)

    # Output PDF to BytesIO
    pdf_bytes = BytesIO()
    pdf_output = pdf.output(dest='S').encode('latin1')  # Save PDF as string, then convert to bytes
    pdf_bytes.write(pdf_output)
    pdf_bytes.seek(0)  # Reset pointer to the start of the BytesIO buffer
    return pdf_bytes.getvalue()

# --- Streamlit GUI ---
st.set_page_config(page_title="Weather Tracker", layout="centered")
st.title("Weather Tracker")
st.write("Enter city names to get their current weather conditions.")

# --- Inputs ---
api_key = st.text_input("Enter your OpenWeatherMap API Key:d9be53e993c0beb99eed1b9e8240d1ed", type="password")
city_input = st.text_area("City Names (separate with commas)", "Cape Town, Durban, Johannesburg")

# --- On Button Click ---
if st.button("Get Weather"):
    if not api_key:
        st.error("⚠️ Please enter your OpenWeatherMap API key.")
    else:
        cities = [c.strip() for c in city_input.split(",") if c.strip()]
        weather_data = []

        for city in cities:
            result = get_weather(city, api_key)
            if "Error" not in result:
                weather_data.append(result)
            else:
                st.warning(f"{result['City']}: {result['Error']}")

        # --- Show Data ---
        if weather_data:
            df = pd.DataFrame(weather_data)
            st.success("✅ Weather data fetched successfully!")
            st.dataframe(df)

            # --- Graph ---
            st.subheader("🌡️ Temperature Comparison")
            fig, ax = plt.subplots(figsize=(8, 4))
            ax.bar(df["City"], df["Temperature (°C)"], color='skyblue')
            ax.set_ylabel("Temperature (°C)")
            ax.set_title("City Temperature")
            st.pyplot(fig)

            # --- Save Graph Image ---
            graph_file = "weather_graph.png"
            fig.savefig(graph_file)

            # --- Download Buttons ---
            st.subheader("📥 Download Results")

            csv = df.to_csv(index=False).encode("utf-8")
            st.download_button("Download CSV", csv, "weather.csv", "text/csv")

            txt = "\n".join([f"{row['City']}: {row['Temperature (°C)']}°C, {row['Condition']}, "
                             f"Humidity {row['Humidity (%)']}%, Wind {row['Wind Speed (m/s)']} m/s"
                             for _, row in df.iterrows()])
            st.download_button("Download TXT", txt, "weather.txt", "text/plain")

            # --- Generate and Download PDF ---
            pdf_data = create_pdf(df, graph_file)
            st.download_button("Download PDF", pdf_data, "weather_report.pdf", "application/pdf")
